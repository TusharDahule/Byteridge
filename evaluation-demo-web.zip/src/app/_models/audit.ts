﻿export class Audit
{
    id: number;
    user: string;
    loginTime: string;
    logoutTime: string;
    ip: string;
}