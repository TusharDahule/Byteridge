import { Component, OnInit } from "@angular/core";
import { first } from "rxjs/operators";

import { Audit, User } from "@/_models";
import { AuditService, AuthenticationService } from "@/_services";
@Component({
  templateUrl: "audit.component.html",
  styles: [
    ".btn {border: 1px solid #ffff} .active {background-color: #94d82d}",
  ],
})
export class AuditComponent implements OnInit {
  currentUser: User;
  audits: Audit[] = [];

  filteredAudits: Audit[] = [];
  searchText: string;
  selectedTimeFormat: string = "12";
  auditsPerPage: number = 5;
  public selectedPage = 1;
  sortBy: string = "id";

  constructor(
    private authenticationService: AuthenticationService,
    private auditService: AuditService
  ) {
    this.currentUser = this.authenticationService.currentUserValue;
  }

  ngOnInit() {
    this.loadAllAudits();
  }

  private loadAllAudits() {
    this.auditService
      .getAll()
      .pipe(first())
      .subscribe((audits) => {
        this.audits = audits;
        let pageIndex = (this.selectedPage - 1) * this.auditsPerPage;
        this.filteredAudits = this.audits.slice(pageIndex, this.auditsPerPage);
      });
  }

  changePageSize(event: Event) {
    console.log(event);
    const newSize = (event.target as HTMLInputElement).value;
    this.auditsPerPage = Number(newSize);
    this.changePage(1);
  }

 /*  sort(event: Event) {
    let sortBy = (event.target as HTMLInputElement).value;
    console.log("sortBy:", sortBy);
    if (sortBy === "loginTime" || sortBy === "logoutTime") {
        this.filteredAudits = this.audits.sort((a, b) =>
        new Date(a[sortBy]) >  new Date(b[sortBy]) ? 1 :  new Date(b[sortBy]) >  new Date(a[sortBy]) ? -1 : 0
      );
    } else {
        this.filteredAudits = this.audits.sort((a, b) =>
        a[sortBy] > b[sortBy] ? 1 : b[sortBy] > a[sortBy] ? -1 : 0
      );
    }
     
  } */

  getPageNumbers(): number[] {
    return Array(Math.ceil(this.audits.length / this.auditsPerPage))
      .fill(0)
      .map((x, i) => i + 1);
  }

  changePage(page) {
    this.selectedPage = page;
    this.slicedAudits();
  }

  slicedAudits() {
    let pageIndex = (this.selectedPage - 1) * this.auditsPerPage;
    let endIndex =
      (this.selectedPage - 1) * this.auditsPerPage + this.auditsPerPage;
    this.filteredAudits = [];
    this.filteredAudits = this.audits.slice(pageIndex, endIndex);
  }
}
