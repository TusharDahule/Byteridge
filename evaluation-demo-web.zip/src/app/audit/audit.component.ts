import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { Audit, User } from '@/_models';
import { AuditService, AuthenticationService } from '@/_services';
import {MatTableDataSource} from '@angular/material/table';
import { searchFilterPipe } from '@/_services/search.pipe';
@Component({ templateUrl: 'audit.component.html' })
export class AuditComponent implements OnInit
{
    currentUser: User;
    audits = [];
    searchText: string;

    constructor(
        private authenticationService: AuthenticationService,
        private auditService: AuditService
    )
    {
        this.currentUser = this.authenticationService.currentUserValue;
    }

    ngOnInit()
    {
        this.loadAllAudits();
    }

    private loadAllAudits()
    {
        this.auditService.getAll()
            .pipe(first())
            .subscribe(audits => 
                this.audits = audits
                );
    }
}